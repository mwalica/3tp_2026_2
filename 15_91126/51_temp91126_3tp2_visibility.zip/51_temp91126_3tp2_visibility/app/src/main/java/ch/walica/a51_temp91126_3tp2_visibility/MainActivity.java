package ch.walica.a51_temp91126_3tp2_visibility;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private Button btnShowHide;
    private TextView tvResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btnShowHide = findViewById(R.id.btnShowHide);
        tvResult = findViewById(R.id.tvResult);

        btnShowHide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (tvResult.getVisibility() == View.VISIBLE) {
                    tvResult.setVisibility(View.INVISIBLE);
                    btnShowHide.setText("Pokaż");
                } else {
                    tvResult.setVisibility(View.VISIBLE);
                    btnShowHide.setText("Ukryj");
                }
            }
        });
    }
}