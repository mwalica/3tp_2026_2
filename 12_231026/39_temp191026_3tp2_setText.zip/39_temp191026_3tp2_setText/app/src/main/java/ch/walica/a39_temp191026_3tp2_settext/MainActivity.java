package ch.walica.a39_temp191026_3tp2_settext;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private LinearLayout main;
    private TextView tvText1;
    private Random random = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        main = findViewById(R.id.main);
        tvText1 = findViewById(R.id.tvText1);

        main.setBackgroundColor(Color.GRAY);

        tvText1.setText("Nowy tekst");
        tvText1.setTextColor(getColor(R.color.color_3));
        tvText1.setBackgroundColor(Color.rgb(ranColor(256), ranColor(256), ranColor(256)));
        tvText1.setPadding(28, 28, 28, 28);
        tvText1.setTextSize(ranColor(97));

    }

    private int ranColor(int end) {
        return random.nextInt(end);
    }
}